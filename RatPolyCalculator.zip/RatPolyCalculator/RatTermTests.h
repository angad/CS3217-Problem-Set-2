#import <SenTestingKit/SenTestingKit.h>
#import <UIKit/UIKit.h>
#import "RatTerm.h"


@interface RatTermTests : SenTestCase {
    RatNum *nanNum;
    RatTerm *nanTerm;
}

@end
